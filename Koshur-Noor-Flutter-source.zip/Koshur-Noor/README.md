# Koshur Noor — coral & peach edition

A Flutter prayer companion inspired by the supplied Qibla reference: coral-to-peach gradients, cream reading cards, cocoa mosque silhouettes, a detailed compass face and matching launcher icon. Amiri Arabic and Nastaliq Kashmiri remain bundled for offline reading.

[Android arm64 preview APK](https://github.com/sameerahmad86232/cipher/raw/refs/heads/noor-downloads/Koshur-Noor-Android-arm64.apk?v=1.3.0) · [Flutter source ZIP](https://github.com/sameerahmad86232/cipher/raw/refs/heads/noor-downloads/Koshur-Noor-Flutter-source.zip)

Android 7.0+, 64-bit ARM. Development-signed preview for sideloading and testing; configure your own signing key before production distribution. Never commit signing secrets.

## Features

- Offline five-prayer calculations, distinct sunrise, next-prayer countdown, monthly timetable and private prayer log.
- Karachi, Muslim World League, Egyptian and Moonsighting Committee methods; Hanafi/standard Asr; manual minute adjustment.
- Eleven manual cities with IANA timezones, plus optional current GPS coordinates using the device’s IANA timezone. Confirm the phone timezone is correct, especially when travelling.
- **Live Android Qibla:** native rotation-vector sensor, accelerometer/magnetometer fallback, display-orientation remapping and Android GeomagneticField correction from magnetic to true north. Kaaba pointer follows the relative bearing; north-crossing angles animate by the shortest route.
- Calibration/low-accuracy guidance, stale/no-sensor states, alignment feedback and explicit manual-location labels. No simulated headings. Web/non-Android builds show a truthful reference-only fallback.
- Opt-in location permission flow, GPS-disabled and blocked-permission handling, enable-location dialog, timeout handling and manual city alternative. The saved position and device timezone apply to prayer calculations too.
- Twelve duas and eight hadiths with Arabic, Kashmiri meaning drafts, references, search, topics, saved favourites, copy/review tools and Arabic size controls.
- Zikr counter with count animation, haptic feedback, selectable target and reset confirmation.
- Fade/slide screen transitions and smoothed compass movement. Custom motion respects the system’s reduced-animation preference. No decorative perpetual animation loop.
- Night palette, larger reading text, no account, ads, model download or app server.

## Privacy and limitations

GPS is requested only after tapping the location button. No background-location permission is requested. Last chosen coordinates, timezone, saved content and counters are stored locally; Android cloud backup is disabled. The app does not send positions to an app server. Android location providers may use the phone’s system location services. Compass subscriptions stop when leaving the screen and native sensors pause when the activity pauses.

The heading depends on actual phone hardware, calibration and magnetic interference. Keep the phone flat and away from metal. A manual city must match your real location. The browser cannot demonstrate the Android sensor implementation. No physical-device sensor or GPS installation test was available in this workspace; do not treat automated tests as a hardware accuracy certification.

Prayer times are calculations, not mosque iqamah times. Kashmiri meanings are **drafts awaiting review**, not certified translations. No background prayer alarms or audio playback are included.

## Build and verify

Tested with Flutter 3.47.7 / Dart 3.13.5, Java 21 and Android SDK 36.

```sh
flutter pub get
flutter analyze
flutter test
flutter run
flutter build apk --release --target-platform android-arm64
flutter build web --release --no-web-resources-cdn
```

Android entry: `android/app/src/main/kotlin/com/koshur/koshur_noor/MainActivity.kt`. Device integration: `lib/device_services.dart`; compass screen: `lib/qibla_screen.dart`; astronomical calculations: `lib/prayer_service.dart`.

See [verification](docs/VERIFICATION.md), [translation review](docs/TRANSLATION_REVIEW.md) and [third-party notices](THIRD_PARTY_NOTICES.md).

Verified 1.3 APK SHA-256: `1f8ed7d15179d4f17a077cfb84823d505760705926c68f8d5cb782e0524bd97a`.
